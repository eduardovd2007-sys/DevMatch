export const bancoDePreguntas: Record<string, any[]> = {
  // === LENGUAJES ===
  "JavaScript": [
    { pregunta: "¿Qué imprimirá el siguiente código en consola?", codigo: "console.log(typeof null);\nconsole.log(typeof undefined);", opciones: ["'null' y 'undefined'", "'object' y 'undefined'", "'object' y 'object'", "'undefined' y 'null'"], correcta: "'object' y 'undefined'" },
    { pregunta: "¿Qué es un closure en JavaScript?", opciones: ["Un tipo de variable", "Una función con acceso a su ámbito léxico", "Un error de sintaxis", "Una clase base"], correcta: "Una función con acceso a su ámbito léxico" },
    { pregunta: "¿Cuál es el resultado de la siguiente ejecución?", codigo: "const arr = [1, 2, 3];\narr[10] = 99;\nconsole.log(arr.length);", opciones: ["3", "11", "Error", "4"], correcta: "11" },
    { pregunta: "¿Qué es el Event Loop?", opciones: ["Un ciclo for infinito", "El modelo de concurrencia de JS", "Una función matemática", "Un plugin de Node"], correcta: "El modelo de concurrencia de JS" },
    { pregunta: "¿Qué imprimirá esto?", codigo: "let x = 1;\nif (true) {\n  let x = 2;\n}\nconsole.log(x);", opciones: ["1", "2", "undefined", "Error"], correcta: "1" }
  ],
  "C++": [
    { pregunta: "¿Qué imprimirá el siguiente código?", codigo: "#include <iostream>\nusing namespace std;\n\nint main() {\n  int x = 5;\n  int *p = &x;\n  cout << *p;\n  return 0;\n}", opciones: ["La dirección de memoria", "5", "Error de compilación", "0"], correcta: "5" },
    { pregunta: "¿Cómo se llama el proceso de liberar memoria asignada dinámicamente?", opciones: ["delete", "remove", "free", "clear"], correcta: "delete" },
    { pregunta: "¿Qué problema tiene el siguiente código?", codigo: "int* ptr = new int[10];\n// ... operaciones ...\ndelete ptr;", opciones: ["Ninguno", "Falta include", "Se debe usar delete[] ptr;", "La sintaxis new int[10] es incorrecta"], correcta: "Se debe usar delete[] ptr;" },
    { pregunta: "¿Qué es un constructor?", opciones: ["Una función para construir la interfaz", "Un método especial que se llama al crear un objeto", "Un puntero a otra clase", "Un operador aritmético"], correcta: "Un método especial que se llama al crear un objeto" },
    { pregunta: "¿Cuál es el resultado de la siguiente operación de bits?", codigo: "int a = 5; // 0101\nint b = 3; // 0011\ncout << (a & b);", opciones: ["1", "8", "7", "0"], correcta: "1" }
  ],
  "TypeScript": [
    { pregunta: "¿Qué añade TypeScript a JavaScript?", opciones: ["Tipado estático", "Clases dinámicas", "Nuevas funciones matemáticas", "Soporte nativo para CSS"], correcta: "Tipado estático" },
    { pregunta: "¿Qué error arrojará el siguiente código en tiempo de compilación?", codigo: "interface User {\n  id: number;\n  name: string;\n}\n\nconst u: User = { id: 1 };", opciones: ["Ninguno", "Property 'name' is missing", "Type 'number' is not assignable to 'string'", "Invalid JSON"], correcta: "Property 'name' is missing" },
    { pregunta: "¿Qué palabra clave se usa para crear un alias de tipo?", opciones: ["interface", "type", "alias", "class"], correcta: "type" },
    { pregunta: "¿Qué imprimirá este código (asumiendo que se transpile sin errores estrictos)?", codigo: "enum Color { Red = 1, Green, Blue }\nconsole.log(Color.Green);", opciones: ["1", "2", "Green", "0"], correcta: "2" },
    { pregunta: "¿Cómo se define una variable de solo lectura en una interfaz?", opciones: ["readonly", "const", "static", "final"], correcta: "readonly" }
  ],
  "Python": [
    { pregunta: "¿Cuál es el resultado del siguiente código?", codigo: "x = [1, 2, 3]\ny = x\ny.append(4)\nprint(x)", opciones: ["[1, 2, 3]", "[1, 2, 3, 4]", "Error", "None"], correcta: "[1, 2, 3, 4]" },
    { pregunta: "¿Qué palabra clave se usa para definir una función en Python?", opciones: ["func", "def", "function", "lambda"], correcta: "def" },
    { pregunta: "¿Qué imprimirá el siguiente código?", codigo: "def foo(a, b=[]):\n    b.append(a)\n    return b\n\nprint(foo(1))\nprint(foo(2))", opciones: ["[1] y [2]", "[1] y [1, 2]", "Error de sintaxis", "None"], correcta: "[1] y [1, 2]" },
    { pregunta: "¿Qué decorador se usa comúnmente para métodos de clase?", opciones: ["@staticmethod", "@classmethod", "@property", "Todas las anteriores"], correcta: "Todas las anteriores" },
    { pregunta: "¿Qué función se usa para obtener la longitud de una lista?", opciones: ["length()", "size()", "len()", "count()"], correcta: "len()" }
  ],

  // === FRONTEND ===
  "Svelte": [
    { pregunta: "¿Cuál es la mayor diferencia de Svelte respecto a React/Vue?", opciones: ["No usa Virtual DOM, compila el código en build-time", "Es 100% backend", "Usa jQuery por debajo", "No soporta TypeScript"], correcta: "No usa Virtual DOM, compila el código en build-time" },
    { pregunta: "¿Qué hace la siguiente línea reactiva en Svelte?", codigo: "<script>\n  let count = 0;\n  $: doubled = count * 2;\n</script>", opciones: ["Crea un error de sintaxis", "Calcula 'doubled' automáticamente cada vez que 'count' cambia", "Define una variable estática", "Llama a jQuery"], correcta: "Calcula 'doubled' automáticamente cada vez que 'count' cambia" },
    { pregunta: "¿Cómo pasas un prop a un componente hijo en Svelte?", codigo: "<script>\n  // ¿Qué debes poner aquí para recibir 'name'?\n  export let name;\n</script>", opciones: ["import { name }", "export let name;", "const name = props.name;", "$props.name"], correcta: "export let name;" },
    { pregunta: "¿Cómo se llama el framework full-stack basado en Svelte?", opciones: ["SvelteKit", "NextSvelte", "Nuxt", "SvelteServer"], correcta: "SvelteKit" },
    { pregunta: "¿En qué formato/extensión se guardan los componentes de Svelte?", opciones: [".jsx", ".vue", ".svelte", ".js"], correcta: ".svelte" }
  ],
  "React": [
    { pregunta: "¿Qué hook se usa para manejar el estado en un componente funcional?", opciones: ["useEffect", "useState", "useContext", "useReducer"], correcta: "useState" },
    { pregunta: "¿Qué imprimirá este componente al montarse?", codigo: "function App() {\n  const [count, setCount] = useState(0);\n  \n  useEffect(() => {\n    setCount(count + 1);\n    setCount(count + 1);\n  }, []);\n\n  return <div>{count}</div>;\n}", opciones: ["0", "1", "2", "Bucle infinito"], correcta: "1" },
    { pregunta: "¿Cómo se pasan datos de un componente padre a un hijo?", opciones: ["Por State", "Por Props", "Por Contexto global", "Por Redux"], correcta: "Por Props" },
    { pregunta: "¿Qué error hay en el siguiente código?", codigo: "function List() {\n  const items = ['A', 'B'];\n  return items.map(item => <div>{item}</div>);\n}", opciones: ["Falta el atributo 'key' en el div", "Falta el return dentro del map", "items.map no es una función", "Ninguno"], correcta: "Falta el atributo 'key' en el div" },
    { pregunta: "¿Qué significa JSX?", opciones: ["JavaScript XML", "Java Syntax Extension", "JSON X", "JavaScript Xtreme"], correcta: "JavaScript XML" }
  ],

  // === BACKEND ===
  "Laravel": [
    { pregunta: "¿Qué retornará este código en Laravel usando Eloquent?", codigo: "$user = User::where('email', 'test@test.com')->first();\nreturn $user->name;", opciones: ["El nombre del usuario o error si no existe", "Un array JSON", "Un objeto de conexión SQL", "Un booleano"], correcta: "El nombre del usuario o error si no existe" },
    { pregunta: "¿Cómo se llama el motor de plantillas por defecto en Laravel?", opciones: ["Twig", "Blade", "Smarty", "EJS"], correcta: "Blade" },
    { pregunta: "¿Qué hace la siguiente ruta?", codigo: "Route::get('/users/{id}', [UserController::class, 'show']);", opciones: ["Guarda un usuario", "Abre la vista de usuarios", "Asigna el ID a la función show del controlador", "Elimina el usuario por ID"], correcta: "Asigna el ID a la función show del controlador" },
    { pregunta: "¿Qué herramienta CLI se usa para generar controladores, modelos y migraciones en Laravel?", opciones: ["composer", "artisan", "npm", "laravel-cli"], correcta: "artisan" },
    { pregunta: "¿Qué comando inicia el servidor de desarrollo en Laravel?", opciones: ["php artisan serve", "php start", "laravel run", "npm start"], correcta: "php artisan serve" }
  ],
  "Node.js": [
    { pregunta: "¿Qué motor de JavaScript utiliza Node.js por debajo?", opciones: ["SpiderMonkey", "V8", "Chakra", "JavaScriptCore"], correcta: "V8" },
    { pregunta: "¿Qué hace este código de Express?", codigo: "app.get('/api', (req, res) => {\n  res.json({ ok: true });\n});", opciones: ["Devuelve HTML", "Devuelve una respuesta JSON 200 al hacer un GET", "Cierra el servidor", "Redirige a /api"], correcta: "Devuelve una respuesta JSON 200 al hacer un GET" },
    { pregunta: "¿Qué objeto global se usa para acceder a las variables de entorno en Node?", opciones: ["window.env", "document.env", "process.env", "global.env"], correcta: "process.env" },
    { pregunta: "¿Qué módulo nativo se usa para leer archivos?", codigo: "const fs = require('fs');\nconst data = fs.readFileSync('archivo.txt');", opciones: ["http", "path", "fs", "crypto"], correcta: "fs" },
    { pregunta: "¿Qué gestor de paquetes viene por defecto al instalar Node.js?", opciones: ["yarn", "pnpm", "npm", "bower"], correcta: "npm" }
  ],

  // === BASES DE DATOS ===
  "SQLite": [
    { pregunta: "¿Qué diferencia a SQLite de otras BD relacionales como MySQL o Postgres?", opciones: ["No usa SQL", "No tiene tipos de datos", "Es una base de datos embebida (un solo archivo), sin servidor separado", "Solo funciona en Linux"], correcta: "Es una base de datos embebida (un solo archivo), sin servidor separado" },
    { pregunta: "¿Qué hará esta consulta en SQLite?", codigo: "CREATE TABLE IF NOT EXISTS users (\n  id INTEGER PRIMARY KEY AUTOINCREMENT,\n  name TEXT NOT NULL\n);", opciones: ["Borrar la tabla users", "Crear la tabla users solo si no existe ya", "Lanzar un error por sintaxis", "Crear una base de datos"], correcta: "Crear la tabla users solo si no existe ya" },
    { pregunta: "¿Qué tipo de dato NO es una clase de almacenamiento estándar en SQLite?", opciones: ["NULL", "INTEGER", "TEXT", "BOOLEAN"], correcta: "BOOLEAN" },
    { pregunta: "¿Qué pasará al ejecutar esto si name espera un texto?", codigo: "INSERT INTO users (name) VALUES (12345);", opciones: ["Error tipo mismatch", "Lo inserta pero convertido a texto (Type Affinity)", "Crasha la DB", "Ignora la inserción"], correcta: "Lo inserta pero convertido a texto (Type Affinity)" },
    { pregunta: "¿En qué entorno se usa muchísimo SQLite?", opciones: ["Clusters de Big Data", "Aplicaciones móviles (iOS/Android)", "Servidores de alta concurrencia mundial", "Inteligencia Artificial"], correcta: "Aplicaciones móviles (iOS/Android)" }
  ],
  "PostgreSQL": [
    { pregunta: "¿Qué tipo de JOIN devuelve todas las filas de la tabla izquierda y las coincidencias de la derecha?", opciones: ["INNER JOIN", "RIGHT JOIN", "LEFT JOIN", "FULL JOIN"], correcta: "LEFT JOIN" },
    { pregunta: "¿Qué retornará este query?", codigo: "SELECT COALESCE(NULL, 'A', 'B');", opciones: ["NULL", "A", "B", "Error"], correcta: "A" },
    { pregunta: "¿Cuál de estos tipos de datos soporta PostgreSQL nativamente que no está en todas las SQL clásicas?", opciones: ["VARCHAR", "INT", "JSONB", "DATE"], correcta: "JSONB" },
    { pregunta: "¿Qué significa la cláusula RETURNING en un INSERT?", codigo: "INSERT INTO users (name) VALUES ('Juan') RETURNING id;", opciones: ["No hace nada", "Cancela la inserción", "Devuelve el ID generado de la fila insertada", "Borra el usuario anterior"], correcta: "Devuelve el ID generado de la fila insertada" },
    { pregunta: "¿Cuál es el puerto por defecto de PostgreSQL?", opciones: ["3306", "5432", "27017", "6379"], correcta: "5432" }
  ],

  // === DEVOPS / CLOUD ===
  "Azure": [
    { pregunta: "¿Qué empresa desarrolla Azure?", opciones: ["Oracle", "Google", "Microsoft", "Amazon"], correcta: "Microsoft" },
    { pregunta: "¿Qué define este bloque de código en un pipeline de Azure DevOps (YAML)?", codigo: "trigger:\n- main\n\npool:\n  vmImage: ubuntu-latest\n\nsteps:\n- script: npm run build", opciones: ["Crea una máquina virtual permanente", "Ejecuta un script de construcción automáticamente cuando hay push a 'main'", "Borra la rama main", "Instala ubuntu localmente"], correcta: "Ejecuta un script de construcción automáticamente cuando hay push a 'main'" },
    { pregunta: "¿Cuál es la base de datos NoSQL globalmente distribuida insignia de Azure?", opciones: ["Azure SQL", "Cosmos DB", "Blob Storage", "Table Storage"], correcta: "Cosmos DB" },
    { pregunta: "¿Cómo se llama el servicio de funciones Serverless de Azure?", opciones: ["Azure Serverless", "Azure Functions", "Azure Lambda", "Azure Run"], correcta: "Azure Functions" },
    { pregunta: "¿Qué herramienta CLI se usa para administrar Azure?", opciones: ["azure-cli (az)", "ms-cli", "gcloud", "aws"], correcta: "azure-cli (az)" }
  ],
  "Docker": [
    { pregunta: "¿Qué es Docker?", opciones: ["Una máquina virtual completa", "Una plataforma para crear, desplegar y ejecutar contenedores", "Un proveedor de nube", "Un sistema operativo"], correcta: "Una plataforma para crear, desplegar y ejecutar contenedores" },
    { pregunta: "¿Qué hace esta línea en un Dockerfile?", codigo: "COPY package*.json ./\nRUN npm install", opciones: ["Borra todos los paquetes", "Copia el package.json y luego instala las dependencias", "Copia la carpeta entera", "Ejecuta el servidor"], correcta: "Copia el package.json y luego instala las dependencias" },
    { pregunta: "¿Qué herramienta se usa para definir y correr aplicaciones Docker multi-contenedor?", opciones: ["Docker Machine", "Docker Compose", "Docker Swarm", "Kubernetes"], correcta: "Docker Compose" },
    { pregunta: "¿Qué significa el comando 'EXPOSE 3000' en un Dockerfile?", codigo: "FROM node:18\nEXPOSE 3000", opciones: ["Abre puertos en el router", "Declara que el contenedor escucha en el puerto 3000", "Detiene el puerto 3000", "No es un comando válido"], correcta: "Declara que el contenedor escucha en el puerto 3000" },
    { pregunta: "¿Qué es un 'Volumen' en Docker?", opciones: ["La memoria RAM asignada", "Un mecanismo para persistir datos generados por el contenedor", "El tamaño de la imagen", "El nivel sonoro de la alerta"], correcta: "Un mecanismo para persistir datos generados por el contenedor" }
  ]
};
