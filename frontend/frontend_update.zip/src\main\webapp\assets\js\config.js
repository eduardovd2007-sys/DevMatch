/**
 * CONFIGURACIÓN GLOBAL DEVMATCH
 * 
 * Antes de subir a AWS (S3, Vercel, o EC2), cambia la URL base 
 * para apuntar a la IP pública o dominio de tu backend.
 * 
 * Ejemplo local de red: 'http://192.168.1.100:3000/api'
 * Ejemplo AWS: 'http://54.123.45.67:3000/api' o 'https://api.midominio.com/api'
 */
window.DEVMATCH_CONFIG = {
  // Si está vacío, intentará autodescubrir la IP local. Si pones un string, forzará ese backend.
  API_URL: 'http://3.230.17.89/api' 
};

// Autodescubrimiento dinámico para red local si no se provee URL fija
if (!window.DEVMATCH_CONFIG.API_URL) {
  window.DEVMATCH_CONFIG.API_URL = `http://${window.location.hostname}:3000/api`;
}
